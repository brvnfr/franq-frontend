import React, { useState } from "react";
import { useAuth } from "@/app/providers/auth-provider";
import { useNavigate, Link } from "react-router-dom";
import { Card, CardContent } from "@/components/ui/card";

const RegisterPage: React.FC = () => {
  const { login } = useAuth();
  const navigate = useNavigate();
  const [email, setEmail] = useState("");
  const [name, setName] = useState("");
  const [error, setError] = useState("");

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!email || !name) {
      setError("Preencha todos os campos.");
      return;
    }
    // Mock simples de cadastro
    login({ id: Date.now().toString(), name, email });
    navigate("/");
  };

  return (
    <div className="flex items-center justify-center min-h-screen bg-muted">
      <Card className="max-w-md w-full p-6 rounded-2xl shadow-2xl bg-white dark:bg-zinc-900">
        <CardContent>
          <h2 className="text-2xl font-bold mb-4 text-center">Cadastro Franq</h2>
          <form onSubmit={handleSubmit} className="space-y-4">
            <input
              type="text"
              placeholder="Nome"
              className="w-full p-3 rounded-lg border bg-muted"
              value={name}
              onChange={e => setName(e.target.value)}
            />
            <input
              type="email"
              placeholder="E-mail"
              className="w-full p-3 rounded-lg border bg-muted"
              value={email}
              onChange={e => setEmail(e.target.value)}
            />
            {error && <div className="text-red-500 text-sm">{error}</div>}
            <button
              type="submit"
              className="w-full bg-blue-600 text-white font-semibold rounded-xl py-3 hover:bg-blue-700 transition"
            >
              Cadastrar
            </button>
          </form>
          <p className="mt-4 text-center text-sm">
            Já tem conta?{" "}
            <Link to="/login" className="text-blue-600 underline">
              Faça login
            </Link>
          </p>
        </CardContent>
      </Card>
    </div>
  );
};

export default RegisterPage;
